# -*- coding: utf-8 -*-
import re, os, json
os.chdir(os.path.dirname(os.path.abspath(__file__)))
S='../site'
def rd(f): return open(f'{S}/{f}',encoding='utf8').read()
def wr(f,s): open(f'{S}/{f}','w',encoding='utf8').write(s)
TR=[]
def T(fr,en,es): TR.append((fr,en,es)); return fr
STAR='<svg viewBox="0 0 24 24" width="30" height="30" aria-hidden="true" focusable="false"><path d="M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4l-5.9 3.1 1.2-6.5L2.5 9.4l6.6-.9z"/></svg>'
stars=''.join(f'<input type="radio" name="rating" id="rt{n}" value="{n}"><label for="rt{n}" title="{n}">{STAR}</label>' for n in (5,4,3,2,1))
progs=[("Force","Strength","Fuerza"),("Détente","Explosiveness","Explosividad"),("Performance athlétique","Athletic performance","Rendimiento atlético"),("Musculation","Bodybuilding","Musculación"),("Nutrition","Nutrition","Nutrición"),("Coaching course à pied","Running coaching","Coaching de carrera a pie"),("Coaching préparation physique","Physical preparation coaching","Coaching de preparación física"),("Création de site","Website creation","Creación de sitio web"),("Formation PDF","PDF course","Formación PDF"),("Autre","Other","Otro")]
opts='<option value="">'+T("Choisis le programme","Choose the program","Elige el programa")+'</option>'+''.join('<option value="'+f+'">'+T(f,e,s)+'</option>' for f,e,s in progs)
html=('<section class="monavis" id="monavis"><div id="avisClients" class="avislist" hidden></div>'
 '<div class="eyebrow">'+T("TON AVIS COMPTE","YOUR OPINION MATTERS","TU OPINIÓN CUENTA")+'</div><h2>'+T("Laisse ton avis","Leave your review","Deja tu opinión")+'</h2>'
 '<p class="muted avintro">'+T("Tu as commandé sur le site ? Tu as reçu un code d'avis avec le récapitulatif de ta commande. Entre-le ici avec ton commentaire. Ton avis sera publié après vérification.","Did you order on the site? You received a review code with your order summary. Enter it here with your comment. Your review will be published after verification.","¿Has hecho un pedido en el sitio? Recibiste un código de opinión con el resumen de tu pedido. Introdúcelo aquí con tu comentario. Tu opinión se publicará tras su verificación.")+'</p>'
 '<form id="avisForm" class="avform" novalidate>'
 '<div class="avrow"><label>'+T("Prénom","First name","Nombre")+'<input name="prenom" maxlength="40" autocomplete="given-name"></label>'
 '<label>'+T("Nom","Last name","Apellido")+'<input name="nom" maxlength="40" autocomplete="family-name"></label>'
 '<label>'+T("Âge","Age","Edad")+'<input name="age" type="number" inputmode="numeric" min="10" max="99"></label></div>'
 '<label>'+T("Programme concerné","Program concerned","Programa en cuestión")+'<select name="programme">'+opts+'</select></label>'
 '<div class="avnote"><span class="avlbl">'+T("Ta note","Your rating","Tu nota")+'</span><div class="rstars" role="radiogroup" aria-label="'+T("Note sur 5","Rating out of 5","Nota sobre 5")+'">'+stars+'</div></div>'
 '<label>'+T("Ton commentaire","Your comment","Tu comentario")+'<textarea name="comment" rows="5" maxlength="1200" placeholder="'+T("Raconte ton expérience : ce que tu as aimé, ce que ça t'a apporté…","Tell us about your experience: what you liked, what it brought you…","Cuenta tu experiencia: lo que te gustó, lo que te aportó…")+'"></textarea></label>'
 '<label>'+T("Ton code d'avis","Your review code","Tu código de opinión")+'<input name="code" maxlength="14" autocomplete="off" autocapitalize="characters" placeholder="AV-XXXX-XXXX" class="avcode"></label>'
 '<div class="avhp" aria-hidden="true"><input name="website" tabindex="-1" autocomplete="off"></div>'
 '<p class="avmsg" id="avMsg" role="status"></p>'
 '<button class="btn" type="submit" id="avGo">'+T("ENVOYER MON AVIS","SUBMIT MY REVIEW","ENVIAR MI OPINIÓN")+'</button>'
 '<p class="muted avsmall">'+T("Ton prénom, l'initiale de ton nom, ton âge et ton commentaire seront affichés. Le code ne fonctionne qu'une fois.","Your first name, the initial of your last name, your age and your comment will be displayed. The code works only once.","Se mostrarán tu nombre, la inicial de tu apellido, tu edad y tu comentario. El código solo funciona una vez.")+'</p>'
 '</form></section>\n')
a=rd('avis.html')
if 'id="monavis"' not in a:
    k=a.index('<section class="ctaband">'); a=a[:k]+html+a[k:]; wr('avis.html',a)
css=rd('style.css')
if '/* v67 debut */' not in css:
    css+='''
/* v67 debut : avis clients */
.monavis{margin:44px 0 10px}.avintro{max-width:720px;font-size:16px;margin:8px 0 20px}
.avform{max-width:760px;background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:24px;display:grid;gap:16px}
.avform label,.avlbl{display:grid;gap:6px;font-weight:700;font-size:14.5px;color:#d8e0dd}
.avrow{display:grid;grid-template-columns:1fr 1fr 110px;gap:12px}
.avform input,.avform select,.avform textarea{width:100%;background:#0a100e;border:1px solid #2c3a36;color:var(--text);border-radius:10px;padding:12px 13px;font:inherit;font-weight:500}
.avform input:focus,.avform select:focus,.avform textarea:focus{outline:2px solid var(--green);outline-offset:1px}
.avform textarea{resize:vertical;min-height:120px}
.avcode{font-family:ui-monospace,Menlo,monospace;letter-spacing:.08em;text-transform:uppercase}
.rstars{display:flex;flex-direction:row-reverse;justify-content:flex-end;gap:4px}
.rstars input{position:absolute;opacity:0;pointer-events:none}
.rstars label{display:block;cursor:pointer;color:#3a4643;transition:color .15s,transform .15s}
.rstars label svg{fill:currentColor;display:block}
.rstars input:checked~label,.rstars label:hover,.rstars label:hover~label{color:#ffb400;filter:drop-shadow(0 0 7px #ffb40066)}
.rstars label:hover{transform:scale(1.12)}
.rstars input:focus-visible+label{outline:2px solid var(--green);border-radius:6px}
.avhp{position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden}
.avmsg{margin:0;min-height:0;font-weight:700}.avmsg.err{color:#ff8a93}.avmsg.ok{color:var(--green)}
.avsmall{margin:0;font-size:14px}
#avisClients{margin:0 0 34px}
.avform .btn{justify-self:start}
@media(max-width:640px){.avrow{grid-template-columns:1fr 1fr}.avrow label:nth-child(3){grid-column:1/-1}.avform{padding:18px}}
/* v67 fin */
'''
    wr('style.css',css)
js=rd('script.js')
if 'HC_AVIS' not in js:
    js+='''
/* HC_AVIS : avis clients (code a usage unique) */
(function(){ try{
  var f=document.getElementById('avisForm'); if(!f) return;
  var t=function(x){ return window.hcT?window.hcT(x):x; };
  var msg=document.getElementById('avMsg'), go=document.getElementById('avGo'), box=document.getElementById('avisClients');
  var STAR='<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true" focusable="false"><path d="M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4l-5.9 3.1 1.2-6.5L2.5 9.4l6.6-.9z"/></svg>';
  function say(x,k){ msg.textContent=x; msg.className='avmsg '+(k||''); }
  function draw(list){
    if(!list||!list.length) return; box.hidden=false; box.innerHTML='';
    list.forEach(function(r){
      var fg=document.createElement('figure'); fg.className='avis';
      var st=document.createElement('div'); st.className='stars'; st.setAttribute('role','img'); st.setAttribute('aria-label',r.rating+'/5'); st.innerHTML=new Array(r.rating+1).join(STAR); fg.appendChild(st);
      var bq=document.createElement('blockquote'), p=document.createElement('p'); p.textContent='« '+r.comment+' »'; bq.appendChild(p); fg.appendChild(bq);
      var fc=document.createElement('figcaption'), b=document.createElement('b'), sp=document.createElement('span');
      b.textContent=r.prenom+' '+r.nom+', '+r.age+' '+t('ans'); sp.textContent=t(r.programme); fc.appendChild(b); fc.appendChild(sp); fg.appendChild(fc); box.appendChild(fg);
    });
  }
  fetch('/api/reviews',{credentials:'same-origin'}).then(function(r){return r.ok?r.json():null}).then(function(d){ if(d) draw(d.reviews); }).catch(function(){});
  f.addEventListener('submit',function(e){
    e.preventDefault();
    var d={}; ['prenom','nom','age','programme','comment','code','website'].forEach(function(n){ d[n]=f.elements[n].value; });
    var rt=f.querySelector('input[name=rating]:checked'); d.rating=rt?rt.value:'';
    if(!d.prenom.trim()||!d.nom.trim()) return say(t('Renseigne ton prénom et ton nom.'),'err');
    if(!d.age) return say(t('Renseigne ton âge.'),'err');
    if(!d.programme) return say(t('Choisis le programme concerné.'),'err');
    if(!d.rating) return say(t('Choisis une note de 1 à 5 étoiles.'),'err');
    if(d.comment.trim().length<10) return say(t('Écris un commentaire (au moins 10 caractères).'),'err');
    if(!d.code.trim()) return say(t('Entre ton code d\\'avis.'),'err');
    go.disabled=true; say(t('Envoi en cours…'));
    fetch('/api/review',{method:'POST',credentials:'same-origin',headers:{'content-type':'application/json'},body:JSON.stringify(d)})
      .then(function(r){ return r.json().then(function(j){ return {ok:r.ok,j:j}; },function(){ return {ok:false,j:{}}; }); })
      .then(function(x){
        go.disabled=false;
        if(x.ok){ f.reset(); say(t('Merci ! Ton avis a bien été envoyé. Il sera publié après vérification.'),'ok'); }
        else say(t(x.j&&x.j.error?x.j.error.replace(/\\s*\\[diagnostic.*$/,''):'Une erreur est survenue. Réessaie dans un instant.'),'err');
      })
      .catch(function(){ go.disabled=false; say(t('Impossible de joindre le serveur. Réessaie dans un instant.'),'err'); });
  });
}catch(e){} })();
'''
    wr('script.js',js)
for fr,en,es in [("ans","years old","años"),("Renseigne ton prénom et ton nom.","Enter your first and last name.","Indica tu nombre y apellido."),("Renseigne ton âge.","Enter your age.","Indica tu edad."),("Choisis le programme concerné.","Choose the program concerned.","Elige el programa en cuestión."),("Choisis une note de 1 à 5 étoiles.","Choose a rating from 1 to 5 stars.","Elige una nota de 1 a 5 estrellas."),("Écris un commentaire (au moins 10 caractères).","Write a comment (at least 10 characters).","Escribe un comentario (al menos 10 caracteres)."),("Entre ton code d'avis.","Enter your review code.","Introduce tu código de opinión."),("Envoi en cours…","Sending…","Enviando…"),("Merci ! Ton avis a bien été envoyé. Il sera publié après vérification.","Thank you! Your review was sent. It will be published after verification.","¡Gracias! Tu opinión ha sido enviada. Se publicará tras su verificación."),("Code invalide ou déjà utilisé.","Invalid or already used code.","Código no válido o ya utilizado."),("Une erreur est survenue. Réessaie dans un instant.","An error occurred. Please try again in a moment.","Ha ocurrido un error. Inténtalo de nuevo en un momento."),("Impossible de joindre le serveur. Réessaie dans un instant.","Unable to reach the server. Please try again in a moment.","No se puede contactar con el servidor. Inténtalo de nuevo en un momento."),("Trop d’essais. Reessaie dans 15 minutes.","Too many attempts. Try again in 15 minutes.","Demasiados intentos. Inténtalo de nuevo en 15 minutos."),("Renseigne ton âge.","Enter your age.","Indica tu edad.")]: TR.append((fr,en,es))
ex=open('extras.py',encoding='utf8').read(); m='# ==== v67 (genere) ===='
if m in ex: ex=ex[:ex.index(m)]
seen=set(); L=[]
for t in TR:
    if t[0] in seen: continue
    seen.add(t[0]); L.append('('+','.join(json.dumps(x,ensure_ascii=False) for x in t)+'),')
ex+='\n'+m+'\nEXACT += [\n'+'\n'.join(L)+'\n]\n'
open('extras.py','w',encoding='utf8').write(ex)
print('ok',len(TR))
