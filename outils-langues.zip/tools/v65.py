# -*- coding: utf-8 -*-
import re, os, json, urllib.parse as U
os.chdir(os.path.dirname(os.path.abspath(__file__)))
S='../site'
def rd(f): return open(f'{S}/{f}',encoding='utf8').read()
def wr(f,s): open(f'{S}/{f}','w',encoding='utf8').write(s)
TR=[]
def T(fr,en,es): TR.append((fr,en,es)); return fr
def wa(cat): return 'https://wa.me/33767927163?text='+U.quote('Bonjour Victor, je voudrais un devis pour un site (catégorie '+cat+').',safe='')
tiers=[
 ('Perso',('PERSO','PERSONAL','PERSONAL'),("Particulier, sportif, étudiant","Individual, athlete, student","Particular, deportista, estudiante"),'50 à 80 €',('50 à 80 €','€50 to €80','50 a 80 €'),("3 à 7 jours","3 to 7 days","3 a 7 días"),'5 €',
  [("Site vitrine de 1 à 3 pages","Showcase site of 1 to 3 pages","Sitio escaparate de 1 a 3 páginas"),("Présentation, photos, liens vers tes réseaux","Presentation, photos, links to your social media","Presentación, fotos, enlaces a tus redes"),("Bouton de contact (WhatsApp ou e-mail)","Contact button (WhatsApp or email)","Botón de contacto (WhatsApp o correo)")]),
 ('Perso +',('PERSO +','PERSONAL +','PERSONAL +'),("Coach, créateur, freelance, association","Coach, creator, freelancer, association","Entrenador, creador, freelance, asociación"),'80 à 150 €',('80 à 150 €','€80 to €150','80 a 150 €'),("7 à 10 jours","7 to 10 days","7 a 10 días"),'10 €',
  [("Site de 4 à 6 pages","Site of 4 to 6 pages","Sitio de 4 a 6 páginas"),("Offres, tarifs, paiement (PayPal, Revolut, virement)","Offers, prices, payment (PayPal, Revolut, bank transfer)","Ofertas, precios, pago (PayPal, Revolut, transferencia)"),("Formulaire de contact, avis, réseaux sociaux","Contact form, reviews, social media","Formulario de contacto, opiniones, redes sociales")]),
 ('Pro',('PRO','PRO','PRO'),("Commerce, restaurant, salle de sport, artisan","Shop, restaurant, gym, craftsperson","Comercio, restaurante, gimnasio, artesano"),'150 à 200 €',('150 à 200 €','€150 to €200','150 a 200 €'),("2 semaines","2 weeks","2 semanas"),'15 €',
  [("Site complet et soigné","Complete, polished site","Sitio completo y cuidado"),("Menu ou offres, horaires, plan d'accès, avis","Menu or offers, opening hours, map, reviews","Menú u ofertas, horarios, mapa, opiniones"),("Référencement de base pour apparaître sur Google","Basic SEO to appear on Google","SEO básico para aparecer en Google")]),
 ('Boutique',('BOUTIQUE','SHOP','TIENDA'),("Vente en ligne","Online selling","Venta en línea"),'150 à 250 €',('150 à 250 €','€150 to €250','150 a 250 €'),("2 semaines","2 weeks","2 semanas"),'20 €',
  [("Catalogue de produits avec photos et prix","Product catalogue with photos and prices","Catálogo de productos con fotos y precios"),("Commandes et paiement en ligne","Orders and online payment","Pedidos y pago en línea"),("Pages produit claires, panier, confirmation de commande","Clear product pages, cart, order confirmation","Páginas de producto claras, carrito, confirmación de pedido")]),
 ('Organisation',('ORGANISATION','ORGANIZATION','ORGANIZACIÓN'),("Entreprise, fac, club, école","Company, university, club, school","Empresa, facultad, club, escuela"),'Dès 200 €',('Dès 200 €','From €200','Desde 200 €'),("À partir de 2 semaines","From 2 weeks","A partir de 2 semanas"),'20 € ou plus',
  [("Site multi-pages avec plusieurs rubriques","Multi-page site with several sections","Sitio de varias páginas con varias secciones"),("Plusieurs langues possibles","Several languages possible","Varios idiomas posibles"),("Devis détaillé selon tes besoins et tes validations","Detailed quote based on your needs and approvals","Presupuesto detallado según tus necesidades y validaciones")]),
]
cards=''
for i,(cat,name,who,pf,pt,delai,mod,feats) in enumerate(tiers):
    pricefr=pf
    li=''.join('<li>'+T(*f)+'</li>' for f in feats)
    mod_fr='Après le 1er mois offert : '+mod+' par modification'
    mod_en='After the free first month: '+{'5 €':'€5','10 €':'€10','15 €':'€15','20 €':'€20','20 € ou plus':'€20 or more'}[mod]+' per change'
    mod_es='Tras el primer mes gratis: '+{'5 €':'5 €','10 €':'10 €','15 €':'15 €','20 €':'20 €','20 € ou plus':'20 € o más'}[mod]+' por modificación'
    cls='tier t'+str(i+1)
    cards+=('<article class="'+cls+'"><span class="num">0'+str(i+1)+'</span><h3>'+T(*name)+'</h3><p class="tierwho">'+T(*who)+'</p>'
      '<div class="tierprice">'+T(pf,pt[1],pt[2])+'</div>'
      '<div class="pills"><span class="pill pill-blue">'+T(*delai)+'</span></div>'
      '<ul>'+li+'</ul>'
      '<p class="tiermod">'+T(mod_fr,mod_en,mod_es)+'</p>'
      '<a class="btn" target="_blank" rel="noopener" href="'+wa(cat)+'">'+T('DEMANDER UN DEVIS','REQUEST A QUOTE','PEDIR UN PRESUPUESTO')+'</a></article>')
inc=[("Le nom de domaine est acheté par moi, tu n'as rien à acheter.","I buy the domain name myself, you have nothing to buy.","Yo compro el nombre de dominio, tú no tienes que comprar nada."),
 ("Les modifications sont offertes pendant le premier mois après la livraison.","Changes are free during the first month after delivery.","Las modificaciones son gratuitas durante el primer mes tras la entrega."),
 ("Un site conforme à la loi : mentions légales, confidentialité, cookies.","A legally compliant site: legal notice, privacy policy, cookies.","Un sitio conforme a la ley: aviso legal, privacidad, cookies."),
 ("Un site adapté au téléphone, à la tablette et à l'ordinateur.","A site that works on phone, tablet and computer.","Un sitio adaptado a móvil, tableta y ordenador."),
 ("Livraison dans les délais indiqués pour chaque catégorie. Je ne crée pas d'applications.","Delivery within the time shown for each category. I do not create apps.","Entrega en los plazos indicados para cada categoría. No creo aplicaciones.")]
incl=('<section class="formules infoprog siteinc"><h3>'+T("Inclus dans chaque catégorie","Included in every category","Incluido en cada categoría")+'</h3><ul>'+''.join('<li>'+T(*x)+'</li>' for x in inc)+'</ul></section>')
ex=('<section class="siteex"><div class="eyebrow">'+T("EXEMPLES","EXAMPLES","EJEMPLOS")+'</div><h2>'+T("Des sites que j'ai créés","Sites I have created","Sitios que he creado")+'</h2><div class="exgrid">'
 '<figure class="exitem"><video controls preload="metadata" playsinline src="assets/exemple-hybride-coaching.mp4#t=0.5"></video><figcaption><h3>'+T("Hybride Coaching","Hybride Coaching","Hybride Coaching")+'</h3><p class="muted">'+T("Mon propre site : coaching sportif, programmes, paiement, trois langues.","My own site: sports coaching, programs, payment, three languages.","Mi propio sitio: coaching deportivo, programas, pago, tres idiomas.")+'</p><a class="btn alt" href="https://sportifhybride.com/" target="_blank" rel="noopener">'+T("VOIR LE SITE →","VISIT THE SITE →","VER EL SITIO →")+'</a></figcaption></figure>'
 '<figure class="exitem"><div class="exlink"><h3>'+T("Site de coach course à pied et préparation physique","Running and physical preparation coach site","Sitio de entrenador de carrera a pie y preparación física")+'</h3><p class="muted">'+T("Un site créé pour un coach en course à pied et en préparation physique.","A site created for a running and physical preparation coach.","Un sitio creado para un entrenador de carrera a pie y preparación física.")+'</p><a class="btn alt" href="https://kenjiinne.com/" target="_blank" rel="noopener">'+T("VOIR LE SITE →","VISIT THE SITE →","VER EL SITIO →")+'</a></div></figure>'
 '</div></section>')
s=rd('creation-site.html')
a=s.index('<div class="grid sitecards"'); b=s.index('</main>')
old=s[a:b]
form=re.search(r'<article class="card" id="formation">.*?</article>',old,re.S).group(0).replace('<article class="card" id="formation">','<article class="card wide" id="formation">',1)
new=('<section class="tiers-wrap"><div class="eyebrow">'+T("SUR DEVIS","ON QUOTE","A PRESUPUESTO")+'</div><h2>'+T("Ton site créé pour toi","Your site, created for you","Tu sitio, creado para ti")+'</h2>'
 '<p class="muted tiersintro">'+T("Choisis la catégorie qui correspond à ton projet. Le prix dépend de la difficulté du site et de ce que tu attends. Tu me décris ton idée, je te confirme le prix exact, puis je crée ton site.","Choose the category that fits your project. The price depends on how complex the site is and what you expect. You describe your idea, I confirm the exact price, then I create your site.","Elige la categoría que encaja con tu proyecto. El precio depende de la dificultad del sitio y de lo que esperas. Me describes tu idea, te confirmo el precio exacto y creo tu sitio.")+'</p>'
 '<div class="tiers">'+cards+'</div></section>'+incl+ex+
 '<div class="grid sitecards" style="margin-top:34px">'+form+'</div>\n')
s=s[:a]+new+s[b:]
wr('creation-site.html',s)
css=rd('style.css')
if '/* v65 debut */' not in css:
    css+='''
/* v65 debut : creation de site, categories */
.tiers-wrap{margin-top:44px}.tiersintro{max-width:760px;font-size:16px;margin:8px 0 24px}
.tiers{display:grid;grid-template-columns:repeat(6,1fr);gap:18px}
.tier{grid-column:span 2;display:flex;flex-direction:column;background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:22px}
.tier:nth-child(n+4){grid-column:span 3}
.tier h3{margin:4px 0 4px;font-size:26px}
.tierwho{margin:0 0 12px;color:#c3ccc9;font-size:15px}
.tierprice{font-size:28px;font-weight:900;color:var(--green);margin-bottom:8px}
.tier ul{margin:10px 0 14px;padding-left:20px;color:#d0d8d5;font-size:15px;line-height:1.5}
.tiermod{margin:auto 0 16px;padding-top:12px;border-top:1px solid var(--line);color:#c0cac6;font-size:14px}
.tier .btn{text-align:center}
.tier.t3{border-color:#2a6db5}.tier.t3 .tierprice{color:#5fb0ff}
.siteinc{margin-top:22px}.siteinc h3{margin:0 0 10px}.siteinc ul{margin:0;padding-left:20px;line-height:1.7;color:#d0d8d5}
.siteex{margin-top:40px}.exgrid{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:14px}
.exitem{margin:0;background:var(--panel);border:1px solid var(--line);border-radius:16px;overflow:hidden;display:flex;flex-direction:column}
.exitem video{width:100%;aspect-ratio:16/9;background:#000;display:block}
.exitem figcaption,.exlink{padding:18px 20px 22px;display:flex;flex-direction:column;gap:10px;flex:1}
.exlink{justify-content:center;height:100%}
.exitem h3{margin:0;font-size:22px}.exitem p{margin:0}.exitem .btn{align-self:flex-start}
@media(max-width:1000px){.tier,.tier:nth-child(n+4){grid-column:span 3}.tier:nth-child(5){grid-column:span 6}}
@media(max-width:720px){.tiers,.exgrid{grid-template-columns:1fr}.tier,.tier:nth-child(n+4),.tier:nth-child(5){grid-column:auto}}
/* v65 fin */
'''
    wr('style.css',css)
# SEO: description creation-site si elle cite un prix
exf=open('extras.py',encoding='utf8').read(); m='# ==== v65 (genere) ===='
if m in exf: exf=exf[:exf.index(m)]
seen=set(); L=[]
for t in TR:
    if t[0] in seen: continue
    seen.add(t[0]); L.append('('+','.join(json.dumps(x,ensure_ascii=False) for x in t)+'),')
exf+='\n'+m+'\nEXACT += [\n'+'\n'.join(L)+'\n]\n'
open('extras.py','w',encoding='utf8').write(exf)
print('ok',len(TR))
