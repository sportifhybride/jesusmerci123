# -*- coding: utf-8 -*-
import re, os, json
os.chdir(os.path.dirname(os.path.abspath(__file__)))
S='../site'
def rd(f): return open(f'{S}/{f}',encoding='utf8').read()
def wr(f,s): open(f'{S}/{f}','w',encoding='utf8').write(s)
TR=[]
def T(fr,en,es):
    TR.append((fr,en,es)); return fr

# ---------- 1) Livraison sous 24 h ----------
old_f="Non. Les programmes sont des contenus numériques envoyés immédiatement après ton paiement : avant de payer, tu acceptes cet envoi immédiat et tu renonces à ton droit de rétractation."
new_f=T("Non. Les programmes sont des contenus numériques envoyés sous 24 heures après ton paiement : avant de payer, tu demandes cet envoi et tu renonces à ton droit de rétractation.",
        "No. Programs are digital content sent within 24 hours of your payment: before paying, you request this delivery and waive your right of withdrawal.",
        "No. Los programas son contenidos digitales enviados en un plazo de 24 horas tras tu pago: antes de pagar, solicitas este envío y renuncias a tu derecho de desistimiento.")
s=rd('faq.html'); assert old_f in s; wr('faq.html',s.replace(old_f,new_f))
s=rd('cgv.html'); o="par email ou sur WhatsApp, en général dans les 5 à 10 minutes suivant la validation du paiement."
assert o in s; wr('cgv.html',s.replace(o,"par email ou sur WhatsApp, sous 24 heures après le paiement."))
oldp="Tu recevras ton programme par email après le paiement. Je te contacte au numéro indiqué pour l'envoyer."
newp=T("Tu recevras ton programme sous 24 heures après le paiement, par email ou sur WhatsApp.","You will receive your program within 24 hours of payment, by email or on WhatsApp.","Recibirás tu programa en un plazo de 24 horas tras el pago, por correo o por WhatsApp.")
oldn="Durée : à partir de 2 mois pour chaque programme."
newn=T("Durée : à partir de 2 mois pour chaque programme. Livraison du PDF sous 24 heures après le paiement.","Duration: from 2 months for every program. The PDF is delivered within 24 hours of payment.","Duración: a partir de 2 meses en cada programa. El PDF se entrega en un plazo de 24 horas tras el pago.")
for f in os.listdir(S):
    if f.endswith('.html'):
        t=rd(f); u=t.replace(oldp,newp).replace(oldn,newn)
        if u!=t: wr(f,u)

# ---------- 2) Accueil enrichi + quiz ----------
home=rd('index.html')
steps=[("01","Je choisis","I choose","Elijo","Je choisis mon programme et ma formule : sans suivi, ou avec suivi pour 5 € de plus.","I pick my program and my option: without follow-up, or with follow-up for €5 more.","Elijo mi programa y mi fórmula: sin seguimiento, o con seguimiento por 5 € más."),
 ("02","Je paie","I pay","Pago","Je paie par PayPal, par carte Revolut ou par virement, en quelques clics.","I pay with PayPal, a Revolut card or a bank transfer, in a few clicks.","Pago con PayPal, tarjeta Revolut o transferencia, en unos clics."),
 ("03","Je reçois","I receive","Recibo","Je reçois mon programme en PDF sous 24 heures après le paiement.","I receive my program as a PDF within 24 hours of payment.","Recibo mi programa en PDF en un plazo de 24 horas tras el pago.")]
h='<section class="section wrap" id="comment"><div class="eyebrow">'+T("SIMPLE ET RAPIDE","SIMPLE AND FAST","SENCILLO Y RÁPIDO")+'</div><h2>'+T("Comment ça marche","How it works","Cómo funciona")+'</h2><div class="steps3">'
for n,a,ae,as_,b,be,bs in steps:
    h+=f'<div class="step"><span class="num">{n}</span><h3>{T(a,ae,as_)}</h3><p>{T(b,be,bs)}</p></div>'
h+='</div></section>\n'
progs=[("force.html","force","FORCE","Bench, deadlift, squat ou SBD","Bench, deadlift, squat or SBD","Banca, peso muerto, sentadilla o SBD","Dès 15 €","From €15","Desde 15 €"),
 ("detente.html","detente","DÉTENTE","Sauter plus haut, gagner en explosivité","Jump higher, gain explosiveness","Saltar más alto, ganar explosividad","Dès 15 €","From €15","Desde 15 €"),
 ("performance-athletique.html","performance","PERFORMANCE ATHLÉTIQUE","Vitesse, puissance et qualités physiques","Speed, power and physical qualities","Velocidad, potencia y cualidades físicas","Dès 20 €","From €20","Desde 20 €"),
 ("musculation.html","musculation","MUSCULATION","6 programmes pour prendre du muscle","6 programs to build muscle","6 programas para ganar músculo","Dès 15 €","From €15","Desde 15 €"),
 ("nutrition.html","nutrition","NUTRITION","Un appel par semaine, calories et macros adaptés","A weekly call, calories and macros tailored to you","Una llamada por semana, calorías y macros adaptados","Dès 5 € / mois","From €5 / month","Desde 5 € / mes"),
 ("coaching.html","coach","COACHING COURSE À PIED","Un plan sur mesure, du 5 km au marathon","A tailored plan, from 5K to marathon","Un plan a medida, del 5 km al maratón","Dès 30 €","From €30","Desde 30 €")]
h+='<section class="section wrap" id="mesprog"><div class="eyebrow">'+T("CHOISIS TON OBJECTIF","CHOOSE YOUR GOAL","ELIGE TU OBJETIVO")+'</div><h2>'+T("Mes programmes","My programs","Mis programas")+'</h2><div class="hpgrid">'
for href,img,name,d,de,ds,p,pe,ps in progs:
    h+=f'<a class="hpcard" href="{href}"><img loading="lazy" src="assets/{img}.webp" alt=""><div><h3>{name}</h3><p>{T(d,de,ds)}</p><span class="hpprice">{T(p,pe,ps)}</span></div></a>'
h+='</div></section>\n'
# quiz
def b(v,k,fr,en,es): return f'<button type="button" data-k="{k}" data-v="{v}">{T(fr,en,es)}</button>'
quiz='<section class="section wrap" id="quiz"><div class="quizbox"><div class="eyebrow">'+T("QUIZ","QUIZ","QUIZ")+'</div><h2>'+T("Quel programme pour moi ?","Which program is right for me?","¿Qué programa me conviene?")+'</h2>'
quiz+='<p class="muted qintro">'+T("Réponds à quelques questions, je te recommande le programme qui te correspond.","Answer a few questions and I'll recommend the program that fits you.","Responde a unas preguntas y te recomiendo el programa que te corresponde.")+'</p>'
quiz+='<div class="qstep" data-step="1"><p class="qq">'+T("Quel est ton objectif principal ?","What is your main goal?","¿Cuál es tu objetivo principal?")+'</p><div class="qopts">'
for v,fr,en,es in [("force","Devenir plus fort","Get stronger","Ser más fuerte"),("muscu","Prendre du muscle","Build muscle","Ganar músculo"),("detente","Sauter plus haut, être plus explosif","Jump higher, be more explosive","Saltar más alto, ser más explosivo"),("perf","Être plus rapide et plus puissant dans mon sport","Be faster and more powerful in my sport","Ser más rápido y potente en mi deporte"),("nutrition","Améliorer mon alimentation","Improve my nutrition","Mejorar mi alimentación"),("course","Progresser en course à pied","Improve my running","Progresar corriendo")]:
    quiz+=b(v,"obj",fr,en,es)
quiz+='</div></div>'
quiz+='<div class="qstep" data-step="2" hidden><p class="qq">'+T("Où t'entraînes-tu ?","Where do you train?","¿Dónde entrenas?")+'</p><div class="qopts">'+b("salle","lieu","En salle de musculation","In a gym","En el gimnasio")+b("maison","lieu","À la maison ou en extérieur","At home or outdoors","En casa o al aire libre")+'</div></div>'
quiz+='<div class="qstep" data-step="3" hidden><p class="qq">'+T("Combien de séances par semaine ?","How many sessions per week?","¿Cuántas sesiones por semana?")+'</p><div class="qopts">'+b("a","seances","2 à 3 séances","2 to 3 sessions","2 a 3 sesiones")+b("b","seances","4 séances","4 sessions","4 sesiones")+b("c","seances","5 séances ou plus","5 sessions or more","5 sesiones o más")+'</div></div>'
quiz+='<div class="qstep" data-step="4" hidden><p class="qq">'+T("Quelle formule préfères-tu ?","Which option do you prefer?","¿Qué fórmula prefieres?")+'</p><div class="qopts">'+b("sans","suivi","Sans suivi : le PDF, en autonomie","Without follow-up: the PDF, on your own","Sin seguimiento: el PDF, de forma autónoma")+b("avec","suivi","Avec suivi (+5 €) : je suis ton évolution sur WhatsApp","With follow-up (+€5): I follow your progress on WhatsApp","Con seguimiento (+5 €): sigo tu evolución por WhatsApp")+'</div></div>'
res=[("sbd","SBD POWERLIFTING","Squat, bench et deadlift réunis dans un seul programme de 2 mois.","Squat, bench and deadlift in a single 2-month program.","Sentadilla, banca y peso muerto en un solo programa de 2 meses.","force.html",20),
 ("detente-salle","DÉTENTE · EN SALLE","Pour gagner en détente et en explosivité avec le matériel de la salle.","To gain jumping ability and explosiveness with gym equipment.","Para ganar salto y explosividad con el material del gimnasio.","detente.html",15),
 ("detente-ext","DÉTENTE · MAISON OU EXTÉRIEUR","Pour gagner en détente et en explosivité avec peu de matériel.","To gain jumping ability and explosiveness with little equipment.","Para ganar salto y explosividad con poco material.","detente.html",15),
 ("perf-salle","PERFORMANCE · EN SALLE","Pour développer ta vitesse, ta puissance et tes qualités physiques en salle.","To develop your speed, power and physical qualities in the gym.","Para desarrollar tu velocidad, potencia y cualidades físicas en el gimnasio.","performance-athletique.html",20),
 ("perf-ext","PERFORMANCE · MAISON OU EXTÉRIEUR","Pour développer ta vitesse, ta puissance et tes qualités physiques avec peu de matériel.","To develop your speed, power and physical qualities with little equipment.","Para desarrollar tu velocidad, potencia y cualidades físicas con poco material.","performance-athletique.html",20),
 ("full","3 FOIS FULL","Le corps entier travaillé à chaque séance, 2 à 3 séances par semaine.","The whole body trained in every session, 2 to 3 sessions per week.","Todo el cuerpo en cada sesión, 2 a 3 sesiones por semana.","musculation.html",15),
 ("double","LE DOUBLE DOUBLE","4 séances par semaine : deux pour le haut du corps, deux pour le bas.","4 sessions per week: two for the upper body, two for the lower body.","4 sesiones por semana: dos para el tren superior, dos para el inferior.","musculation.html",15),
 ("gymbro","GYM BRO","5 séances par semaine : haut du corps, jambes et full body.","5 sessions per week: upper body, legs and full body.","5 sesiones por semana: tren superior, piernas y full body.","musculation.html",15),
 ("homebody","HOME BODY","Un programme à faire à la maison, pour tous les niveaux.","A program to do at home, for all levels.","Un programa para hacer en casa, para todos los niveles.","musculation.html",15)]
for key,name,r,re_,rs,href,base in res:
    quiz+=f'<div class="qres" data-res="{key}" hidden><div class="eyebrow">{T("MON CONSEIL POUR TOI","MY ADVICE FOR YOU","MI CONSEJO PARA TI")}</div><h3>{name}</h3><p>{T(r,re_,rs)}</p>'
    quiz+=f'<p class="qprice"><span data-s="sans">{T(f"{base} € · sans suivi",f"€{base} · without follow-up",f"{base} € · sin seguimiento")}</span><span data-s="avec">{T(f"{base+5} € · avec suivi",f"€{base+5} · with follow-up",f"{base+5} € · con seguimiento")}</span></p>'
    quiz+=f'<p class="muted qnut">{T("Ajoute la nutrition pour 5 € par mois avec ton programme.","Add nutrition for €5 per month with your program.","Añade la nutrición por 5 € al mes con tu programa.")}</p><div class="buttons"><a class="btn" href="{href}">{T("VOIR CE PROGRAMME","SEE THIS PROGRAM","VER ESTE PROGRAMA")}</a><button type="button" class="btn alt qreset">{T("RECOMMENCER","START OVER","EMPEZAR DE NUEVO")}</button></div></div>'
quiz+=f'<div class="qres" data-res="nutrition" hidden><div class="eyebrow">{T("MON CONSEIL POUR TOI","MY ADVICE FOR YOU","MI CONSEJO PARA TI")}</div><h3>NUTRITION</h3><p>{T("Un appel par semaine, des calories et des macros adaptés à ton objectif, et un suivi permanent.","A weekly call, calories and macros adapted to your goal, and ongoing follow-up.","Una llamada por semana, calorías y macros adaptados a tu objetivo, y un seguimiento permanente.")}</p><p class="qprice"><span>{T("5 € / mois avec un programme · 10 € / mois sans programme","€5 / month with a program · €10 / month without a program","5 € / mes con un programa · 10 € / mes sin programa")}</span></p><div class="buttons"><a class="btn" href="nutrition.html">{T("VOIR LA NUTRITION","SEE NUTRITION","VER LA NUTRICIÓN")}</a><button type="button" class="btn alt qreset">{T("RECOMMENCER","START OVER","EMPEZAR DE NUEVO")}</button></div></div>'
quiz+=f'<div class="qres" data-res="course" hidden><div class="eyebrow">{T("MON CONSEIL POUR TOI","MY ADVICE FOR YOU","MI CONSEJO PARA TI")}</div><h3>{T("COACHING COURSE À PIED","RUNNING COACHING","COACHING DE CARRERA A PIE")}</h3><p>{T("Un plan sur mesure, du 5 km au marathon, à partir de 8 semaines.","A tailored plan, from 5K to marathon, starting at 8 weeks.","Un plan a medida, del 5 km al maratón, a partir de 8 semanas.")}</p><p class="qprice"><span>{T("À partir de 30 € pour 2 mois","From €30 for 2 months","Desde 30 € por 2 meses")}</span></p><div class="buttons"><a class="btn" href="coaching.html">{T("VOIR LE COACHING","SEE THE COACHING","VER EL COACHING")}</a><button type="button" class="btn alt qreset">{T("RECOMMENCER","START OVER","EMPEZAR DE NUEVO")}</button></div></div>'
quiz+=f'<button type="button" class="qback" hidden>{T("← Retour","← Back","← Volver")}</button></div></section>\n'
h+=quiz
# témoignages
tm=[("« Victor m'a beaucoup aidé dans ma préparation cet été. Grâce à son travail, j'ai fait un bon début de saison, sans aucun pépin physique, et j'ai même pu développer certains aspects de mon physique. Merci beaucoup ! »","Thierno, 18 ans","Basket-ball · centre de formation de Reims"),
    ("« Franchement, super expérience ! Un coach à l'écoute, qui prend le temps de bien expliquer et qui sait mettre à l'aise. J'ai vraiment apprécié l'échange et ses conseils. On sent qu'il aime ce qu'il fait et qu'il est investi dans son accompagnement. Je recommande à 100 % ! »","Akram, 17 ans","Course à pied"),
    ("« Victor m'a permis d'en apprendre plus sur le monde des compléments alimentaires, un monde qui m'était complètement inconnu et que je comprends maintenant beaucoup mieux ! »","Merwan, 18 ans","Demi-fond · États-Unis · universitaire · niveau national")]
star='<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="M12 2.5l2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4l-5.9 3.1 1.2-6.5L2.5 9.4l6.6-.9z"/></svg>'
h+='<section class="section wrap" id="avishome"><div class="eyebrow">'+T("ILS M'ONT FAIT CONFIANCE","THEY TRUSTED ME","CONFIARON EN MÍ")+'</div><h2>'+T("Ce qu'ils en disent","What they say","Lo que dicen")+'</h2><div class="hpavis">'
for q,n,sp in tm:
    h+=f'<figure class="hpq"><div class="stars" aria-hidden="true">{star*5}</div><blockquote>{q}</blockquote><figcaption><b>{n}</b><span>{sp}</span></figcaption></figure>'
h+='</div><div class="buttons"><a class="btn alt" href="avis.html">'+T("VOIR TOUS LES AVIS","SEE ALL REVIEWS","VER TODAS LAS OPINIONES")+'</a></div></section>\n'
if 'id="comment"' not in home:
    home=home.replace('<section class="section wrap" id="sponsor">',h+'<section class="section wrap" id="sponsor">',1)
    wr('index.html',home)

# ---------- 3) CSS ----------
css=rd('style.css')
if 'v61' not in css:
    css+='''
/* v61 : accueil enrichi, quiz, bandeau cookies discret */
.steps3{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-top:22px}
.step{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:22px}
.step h3{margin:8px 0 6px;font-size:24px}.step p{margin:0;color:#c4cdca}
.hpgrid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-top:22px}
.hpcard{display:flex;flex-direction:column;background:var(--panel);border:1px solid var(--line);border-radius:14px;overflow:hidden;transition:transform .2s,border-color .2s}
.hpcard:hover{transform:translateY(-3px);border-color:var(--green)}
.hpcard img{height:150px;object-fit:cover}
.hpcard div{padding:16px 18px 18px}.hpcard h3{margin:0 0 6px;font-size:20px;line-height:1.1}.hpcard p{margin:0 0 10px;color:#b9c4c0;font-size:14.5px}
.hpprice{display:inline-block;padding:6px 10px;background:#10241a;border:1px solid #237344;color:var(--green);border-radius:99px;font-weight:800;font-size:13px}
.quizbox{background:linear-gradient(120deg,#0d1b16,#0a0f14);border:1px solid #237344;border-radius:18px;padding:30px}
.quizbox h2{font-size:clamp(28px,4vw,44px);margin:6px 0 8px}
.qq{font-size:20px;font-weight:800;margin:16px 0 12px}
.qopts{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}
.qopts button{padding:14px 16px;text-align:left;border-radius:10px;border:1px solid #2c3a36;background:#0b1110;color:#fff;font-size:15px;font-weight:700;cursor:pointer}
.qopts button:hover{border-color:var(--green);background:#10241a}
.qres h3{font-size:clamp(26px,3.6vw,38px);margin:6px 0 8px}.qres p{color:#d3dcd8}
.qprice span{display:none;font-weight:900;color:var(--green);font-size:20px}
.qprice span:only-child,.quizbox[data-suivi=sans] .qprice span[data-s=sans],.quizbox[data-suivi=avec] .qprice span[data-s=avec]{display:inline}
.qback{margin-top:16px;background:none;border:0;color:#a6b1ad;cursor:pointer;font-size:14px;padding:6px 0}
.hpavis{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin:22px 0}
.hpq{margin:0;background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:20px;display:flex;flex-direction:column;gap:10px}
.hpq .stars{display:flex;gap:3px;color:#ffc531}.hpq .stars svg{fill:#ffc531}
.hpq blockquote{margin:0;font-style:italic;color:#d3dcd8;font-size:15px;line-height:1.5}
.hpq figcaption{margin-top:auto;display:flex;flex-direction:column;font-size:13px;color:var(--muted)}.hpq figcaption b{color:#fff;font-size:14px}
@media(max-width:900px){.steps3,.hpgrid,.hpavis{grid-template-columns:1fr}.qopts{grid-template-columns:1fr}.hpcard img{height:130px}}
.cookie{left:12px;right:auto;bottom:12px;max-width:390px;padding:10px 12px;border-radius:10px;font-size:12.5px;line-height:1.35;box-shadow:0 8px 24px #000}
.cookie b{font-size:13px}.cookie-actions{margin-top:8px}.cookie button{padding:6px 10px;font-size:12px}
@media(max-width:600px){.cookie{left:8px;right:8px;max-width:none;bottom:8px}}
'''
    wr('style.css',css)

# ---------- 4) JS du quiz ----------
js=rd('script.js')
if 'HC_QUIZ' not in js:
    js+='''
/* HC_QUIZ : "Quel programme pour moi ?" (page d'accueil) */
(function(){
  var box = document.getElementById('quiz'); if(!box) return;
  var q = box.querySelector('.quizbox'), st = {}, hist = [];
  var back = box.querySelector('.qback');
  function aff(sel){
    box.querySelectorAll('.qstep,.qres').forEach(function(e){ e.hidden = !e.matches(sel); });
    var intro = box.querySelector('.qintro'); if(intro) intro.hidden = !/data-step/.test(sel);
    back.hidden = !hist.length || /qres|data-res/.test(sel);
  }
  function cle(){
    var o = st.obj;
    if(o === 'force') return 'sbd';
    if(o === 'detente') return 'detente-' + (st.lieu === 'salle' ? 'salle' : 'ext');
    if(o === 'perf') return 'perf-' + (st.lieu === 'salle' ? 'salle' : 'ext');
    if(o === 'muscu') return st.lieu === 'maison' ? 'homebody' : ({a:'full', b:'double', c:'gymbro'}[st.seances] || 'full');
    return o;
  }
  function suite(){
    var o = st.obj;
    if(!o) return aff('[data-step="1"]');
    if(['detente','perf','muscu'].indexOf(o) > -1 && !st.lieu) return aff('[data-step="2"]');
    if(o === 'muscu' && st.lieu === 'salle' && !st.seances) return aff('[data-step="3"]');
    if(['nutrition','course'].indexOf(o) === -1 && !st.suivi) return aff('[data-step="4"]');
    q.dataset.suivi = st.suivi || '';
    aff('[data-res="' + cle() + '"]');
  }
  box.addEventListener('click', function(e){
    var b = e.target.closest('button'); if(!b) return;
    if(b.dataset.k){ st[b.dataset.k] = b.dataset.v; hist.push(b.dataset.k); suite(); }
    else if(b.classList.contains('qreset')){ st = {}; hist = []; suite(); }
    else if(b.classList.contains('qback')){ var k = hist.pop(); if(k) delete st[k]; suite(); }
  });
  suite();
})();
'''
    wr('script.js',js)

# ---------- 5) CSP : YouTube pour une future video ----------
h2=rd('_headers')
if 'frame-src' not in h2:
    h2=h2.replace("object-src 'none'","object-src 'none'; frame-src https://www.youtube-nocookie.com")
    wr('_headers',h2)

# ---------- 6) traductions ----------
ex=open('extras.py',encoding='utf8').read()
m='# ==== v61 (genere) ===='
if m in ex: ex=ex[:ex.index(m)]
seen=set(); L=[]
for a,b_,c in TR:
    if a in seen: continue
    seen.add(a); L.append('('+json.dumps(a,ensure_ascii=False)+','+json.dumps(b_,ensure_ascii=False)+','+json.dumps(c,ensure_ascii=False)+'),')
ex+='\n'+m+'\nEXACT += [\n'+'\n'.join(L)+'\n]\n'
open('extras.py','w',encoding='utf8').write(ex)
print('ok',len(TR))
